# Task: port `libontology` to pyoxigraph + reasonable (+ our own patch rules)

Repo: internal DSecO repo, package in `tools/libontology/`. Tests use `unittest` and run with `uv`.
Model: Opus 5.5. Start in plan mode. Work on a new branch.

## Decision already taken

- Storage, query and update: **pyoxigraph** instead of rdflib.
- Inference: **reasonable** (Rust OWL 2 RL reasoner, pin `reasonable==0.4.4`), plus **our own patch rules** for what it misses. Each patch rule is one SPARQL UPDATE file (`.sparql`, like the repo's queries) in `libontology/rules/`, named after the W3C OWL 2 RL rule.
- Accepted losses, and only these: `owl:sameAs`, triples with a literal as subject, and owlrl's axiomatic schema noise (reflexive subClassOf/subPropertyOf/equivalent*, `domain/range owl:Thing`, `xsd:* a rdfs:Datatype`, datatype disjointness, `owl:Nothing subClassOf`). These are coded explicitly in `tests/test_ontology_parity.py`.
- rdflib stays only where it has to: as `reasonable`'s term type and for pyshacl. owlrl stays only as a **test dependency** (the parity reference).

## Seed files (already written and passing; copy them into the package)

- `libontology/ontology_reasoning.py`: class `OntologyReasoner`, whose `materialize(store)` alternates reasonable and the patch rules until a fixpoint.
- `libontology/rules/prp-spo2.sparql`: property chains. reasonable 0.4.4 does not apply them, and DSecO needs `isCNAMEOfCNAMEOf` and `hasAS = (isPartOf hasAS)`.
- `libontology/rules/scm-dom2.sparql`, `scm-rng2.sparql`: sub-properties inherit domain/range.
- `tests/test_ontology_reasoning.py` + `tests/test_reasoning/test_onto.ttl`: one test per OWL construct used in DSecO.
- `tests/test_ontology_parity.py` + `tests/test_parity/`: new vs owlrl on DSecO 2.0.0 + the public test individuals, plus a replay of the builder's update loop. The accepted differences are coded explicitly in this file.
- `bench/bench_update_loop.py --ontology … --queries-dir …`: times the builder's update loop, old vs new.

Results on the public test data: 16/16 tests pass. If the patch rules are removed, the parity test fails and lists the 45 missing chain/inverse triples.

## What to do

### Phase 0: analyse, then STOP and report
Read all of `tools/libontology/` and its tests, and every caller (`builder.sh`, `builder_functions.sh`, `builder.py`, scripts in `evaluation/` and `ontology/*/data_generator/`). Write `docs/libontology_migration/00_inventory.md` covering:
- The public API (classes, functions, CLI entry points in `pyproject.toml`) and what each one does.
- Every rdflib usage and its pyoxigraph equivalent, or a proposed solution if there is none (prefix handling, `preserve_namespaces`, `serialize` formats, RDF/XML conversion, blank nodes, `ask/describe/stats/compare/smart_diff`, pyshacl).
- Every place inference happens: `ontology_update` (infers before each update), `ontology_bulk_update` (`infer_each`), and `ontology_infer` (owlrl/pellet/hermit via owlready2; keep pellet/hermit as they are).
- Anything that depends on rdflib-specific behaviour.
- Any OWL construct in the internal ontology versions that is NOT covered by `tests/test_ontology_reasoning.py` (internal versions may differ from the public 2.0.0).

### Phase 1: port, module by module
- Keep every public name, signature, CLI flag and output format. Callers must work unchanged.
- Keep the current order in `update`: infer, then run the UPDATE, then save (the same semantics as today).
- Add `[tool.setuptools.package-data] libontology = ["rules/*.sparql"]` to `pyproject.toml` so the patch rules ship with the package.
- Inferred triples go into the same default graph as the asserted ones, exactly like today's output files.
- Output Turtle: keep the prefixes from the input (today's `preserve_namespaces`). The team prefers bracket-style `[ ... ]` blank nodes; check what pyoxigraph writes and handle it if it differs.

### Phase 2: complete the inference
- For every OWL construct found in Phase 0 that isn't covered yet, first add a test in `tests/test_ontology_reasoning.py`. If reasonable misses it, add a patch rule in `rules/`, with the Orange license header and a comment block (rule name, the if/then, a DSecO example), like the existing ones.
- Chains longer than 2 are not handled by `prp-spo2.sparql`. Add support only if an ontology uses one.

### Phase 3: prove it
- Run `tests/test_ontology_parity.py` on the fixtures AND on a real full build output: `LIBONTOLOGY_PARITY_KG=/path/onto.ttl uv run python -m unittest tests.test_ontology_parity`.
- Run all existing libontology tests and the repo's query/conformity tests (`unittests.queries.sh` etc.) against the new version. Results must be identical.
- Run `bench/bench_update_loop.py` on the real graph and put the table in `docs/libontology_migration/01_results.md`.

## Writing style: IMPORTANT, keep it identical to the old libontology

The new code must look like the old code: same structure, same kind of comments. Before writing, read 3–4 old modules (`ontology_update.py`, `ontology_query.py`, `ontology_infer.py`, `base_ontology.py`) and their tests, and copy their conventions exactly:
- The same Orange license header at the top of every `.py` and `.sparql` file. Python modules start with `#!/usr/bin/env python3` and `# -*- coding: utf-8 -*-`. Test files have only the license header.
- One module per command (`ontology_<name>.py`), each with a class extending the base class plus a `main()` with argparse and `--version`, and the same CLI entry points in `pyproject.toml`.
- A module docstring in numpydoc style: a one-line summary, a short paragraph, then `Classes` / `Functions` sections listing what's in the file (and `Notes` when useful).
- Class docstrings: what the class does, then a `Methods` section with signatures and one-line descriptions.
- Method docstrings: numpydoc `Parameters` / `Returns` / `Raises` sections.
- The same colored messages on stderr/stdout: `\033[92m[+] …` success, `\033[91m[-] …` error, `\033[96m[*] …` info, `\033[93m[~] …` warning.
- Tests: `unittest`, one `test_ontology_<name>.py` per module, fixtures in a `tests/test_<name>/` folder, paths like `./tests/test_<name>/…` (run from `tools/libontology`), with module, class and method docstrings like `test_ontology_update.py`.
- Short inline comments that explain *why*, as in the old code. Simple code: no clever abstractions, no heavy type annotations if the old code doesn't use them.
- Don't rename or reorganize anything that already exists. The seed files already follow these rules; use them as examples.

## Rules
- Never widen the allow-list in `tests/test_ontology_parity.py` or weaken a test to make it pass. Report the difference to me instead.
- Stop and summarise after Phase 0 and after Phase 3.
- If unsure what the reference inference is, ask me.
