#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Copyright (c) 2023-2026 Orange. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#     1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#     2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#     3. All advertising materials mentioning features or use of this software must display the following acknowledgement:
#     This product includes software developed by Orange.
#     4. Neither the name of Orange nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY Orange "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Orange BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

"""
Module for performing OWL 2 RL inference on a pyoxigraph store.

This module replaces the owlrl closure (rdflib) by the reasonable reasoner
(written in Rust) completed with our own patch rules. The patch rules are
SPARQL UPDATE files stored in the rules/ folder, one file per OWL 2 RL rule
that reasonable does not apply.

Classes
-------
OntologyReasoner
    Computes the inference closure of a pyoxigraph store.

Notes
-----
Compared to owlrl, we do not keep owl:sameAs, triples with a literal as
subject, and the axiomatic schema triples of OWL 2 RL (reflexive
subClassOf, "rdfs:domain owl:Thing", datatype disjointness...).
"""

import tempfile
from pathlib import Path
import pyoxigraph as ox
import rdflib
import reasonable

RULES_DIR = Path(__file__).parent / "rules"


class OntologyReasoner:
    """
    Class for computing the inference closure of a pyoxigraph store.

    The closure is computed in rounds: reasonable first, then our patch
    rules. We stop when the patch rules do not add any new triple.

    Methods
    -------
    load_patch_rules(rules_dir: Path) -> dict
        Reads the SPARQL UPDATE files of the patch rules.
    run_reasonable(store: pyoxigraph.Store)
        Adds the triples inferred by reasonable to the store.
    materialize(store: pyoxigraph.Store) -> int
        Computes the full closure and returns the number of rounds.
    """

    def __init__(self, rules_dir=RULES_DIR, max_rounds=20):
        """
        Initialize the reasoner with the folder of the patch rules.

        Parameters
        ----------
        rules_dir : Path
            Folder containing the patch rules (.sparql files).
        max_rounds : int
            Safety limit on the number of rounds.
        """
        self.rules = self.load_patch_rules(rules_dir)
        self.max_rounds = max_rounds

    def load_patch_rules(self, rules_dir):
        """
        Read every patch rule of the folder, sorted by file name.

        Parameters
        ----------
        rules_dir : Path
            Folder containing the patch rules (.sparql files).

        Returns
        -------
        rules : dict
            Mapping {rule name: SPARQL UPDATE query}.
        """
        return {
            path.stem: path.read_text(encoding="utf-8")
            for path in sorted(Path(rules_dir).glob("*.sparql"))
        }

    def run_reasonable(self, store):
        """
        Add the OWL 2 RL closure computed by reasonable to the default graph.

        Parameters
        ----------
        store : pyoxigraph.Store
            The store to infer on. It is modified in place.
        """
        # reasonable only reads turtle files, and N-Triples is valid turtle
        with tempfile.NamedTemporaryFile(suffix=".ttl") as temp_file:
            store.dump(temp_file.name, format=ox.RdfFormat.N_TRIPLES,
                       from_graph=ox.DefaultGraph())
            reasoner = reasonable.PyReasoner()
            reasoner.load_file(temp_file.name)
            triples = reasoner.reason()

        store.extend(
            ox.Quad(to_oxigraph(s), to_oxigraph(p), to_oxigraph(o))
            for s, p, o in triples
            # pyoxigraph refuses literals as subject
            if not isinstance(s, rdflib.Literal)
            # "x owl:sameAs x" brings no information
            and not (p == rdflib.OWL.sameAs and s == o)
        )

    def materialize(self, store):
        """
        Compute the full inference closure of the store.

        Each round runs reasonable, then every patch rule. The output of
        reasonable is already closed for its own rules, so we stop as soon
        as the patch rules add nothing.

        Parameters
        ----------
        store : pyoxigraph.Store
            The store to infer on. It is modified in place.

        Returns
        -------
        rounds : int
            The number of rounds needed to reach the closure.

        Raises
        ------
        RuntimeError
            If the closure is not reached after max_rounds rounds.
        """
        for rounds in range(1, self.max_rounds + 1):
            self.run_reasonable(store)
            size_before = len(store)
            for query in self.rules.values():
                store.update(query)
            if len(store) == size_before:
                return rounds
        raise RuntimeError(f"No closure reached after {self.max_rounds} rounds")


def to_oxigraph(term):
    """
    Convert an rdflib term (as returned by reasonable) into a pyoxigraph term.

    Parameters
    ----------
    term : rdflib.term.Node
        An URIRef, a BNode or a Literal.

    Returns
    -------
    term : pyoxigraph.NamedNode or pyoxigraph.BlankNode or pyoxigraph.Literal
        The same term for pyoxigraph.
    """
    if isinstance(term, rdflib.URIRef):
        return ox.NamedNode(str(term))
    if isinstance(term, rdflib.BNode):
        return ox.BlankNode(str(term))
    if term.language:
        return ox.Literal(str(term), language=term.language)
    datatype = ox.NamedNode(str(term.datatype)) if term.datatype else None
    return ox.Literal(str(term), datatype=datatype)
