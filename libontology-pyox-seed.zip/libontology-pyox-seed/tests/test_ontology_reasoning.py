# Copyright (c) 2023-2026 Orange. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#     1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#     2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#     3. All advertising materials mentioning features or use of this software must display the following acknowledgement:
#     This product includes software developed by Orange.
#     4. Neither the name of Orange nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY Orange "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Orange BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

"""
Test module for the OWL 2 RL inference on a pyoxigraph store.

This module contains one unit test per OWL construct used in dseco. If a new
version of reasonable or a patch rule breaks a construct, only the test of
this construct fails.

Classes
-------
TestOntologyReasoner
    Test cases for the OntologyReasoner class.

Test Cases
----------
test_subclass ... test_no_literal_as_subject
    Tests that each construct gives the expected inferred triples.
"""

import unittest
import pyoxigraph as ox
from libontology.ontology_reasoning import OntologyReasoner


class TestOntologyReasoner(unittest.TestCase):
    """
    A class to test the `OntologyReasoner` class.

    Methods
    -------
    setUpClass()
        Loads the test ontology and computes its closure once.
    assertInferred(*patterns)
        Checks that every triple pattern is in the closure.
    """

    PREFIXES = """
        PREFIX : <http://example.org/>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    """

    @classmethod
    def setUpClass(cls):
        """
        Load the test ontology into a store and compute its closure.
        """
        cls.ontology_path = "./tests/test_reasoning/test_onto.ttl"
        cls.store = ox.Store()
        cls.store.load(path=cls.ontology_path, format=ox.RdfFormat.TURTLE)
        OntologyReasoner().materialize(cls.store)

    def assertInferred(self, *patterns):
        """
        Check that every triple pattern is in the closure.

        Parameters
        ----------
        *patterns : str
            Triple patterns in SPARQL syntax, e.g. ":x1 a :B1".
        """
        for pattern in patterns:
            with self.subTest(pattern=pattern):
                query = f"{self.PREFIXES} ASK {{ {pattern} }}"
                self.assertTrue(self.store.query(query), f"not inferred: {pattern}")

    def test_subclass(self):
        """Test the rule cax-sco (subClassOf)."""
        self.assertInferred(":x1 a :B1", ":x1 a :C1")

    def test_equivalent_class(self):
        """Test the rules cax-eqc1 and cax-eqc2 (equivalentClass)."""
        self.assertInferred(":x2 a :B2", ":y2 a :A2")

    def test_union(self):
        """Test the rule cls-uni (unionOf)."""
        self.assertInferred(":x3 a :U3")

    def test_subproperty(self):
        """Test the rule prp-spo1 (subPropertyOf)."""
        self.assertInferred(":x4 :q4 :y4")

    def test_domain_range(self):
        """Test the rules prp-dom and prp-rng (domain and range)."""
        self.assertInferred(":x5 a :D5", ":y5 a :R5")

    def test_inverse(self):
        """Test the rules prp-inv1 and prp-inv2 (inverseOf)."""
        self.assertInferred(":y6 :q6 :x6", ":b6 :p6 :a6")

    def test_transitive(self):
        """Test the rule prp-trp (TransitiveProperty)."""
        self.assertInferred(":a7 :p7 :c7")

    def test_symmetric(self):
        """Test the rule prp-symp (SymmetricProperty)."""
        self.assertInferred(":b8 :p8 :a8")

    def test_property_chain(self):
        """Test the patch rule prp-spo2 (propertyChainAxiom), like isCNAMEOfCNAMEOf."""
        self.assertInferred(":a9 :cc9 :d9")

    def test_property_chain_then_inverse(self):
        """
        Test that the inverse also applies to the triples made by a chain,
        like hasAS = (isPartOf hasAS) and originates = inverse of hasAS.
        """
        self.assertInferred(":ip10 :hasAS10 :as10", ":as10 :originates10 :ip10")

    def test_property_chain_then_range(self):
        """Test that a chained triple is typed by the range, then by subClassOf."""
        self.assertInferred(":c11 a :R11", ":c11 a :S11")

    def test_subproperty_inherits_range(self):
        """Test the patch rule scm-rng2, like isATo and resolvesTo."""
        self.assertInferred(":isATo12 rdfs:range :IP12")

    def test_no_literal_as_subject(self):
        """Test that the closure has no literal as subject."""
        for quad in self.store:
            self.assertNotIsInstance(quad.subject, ox.Literal)


if __name__ == "__main__":
    unittest.main()
