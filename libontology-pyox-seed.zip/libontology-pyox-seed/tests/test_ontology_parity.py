# Copyright (c) 2023-2026 Orange. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#     1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#     2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#     3. All advertising materials mentioning features or use of this software must display the following acknowledgement:
#     This product includes software developed by Orange.
#     4. Neither the name of Orange nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY Orange "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Orange BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

"""
Test module comparing the new inference with the old one.

The new inference (pyoxigraph + reasonable + patch rules) must give the same
triples as the old one (rdflib + owlrl), except the differences we accepted:
owl:sameAs, literals as subject and the axiomatic schema triples of owlrl.

To run the tests on another graph (for example a full build output):
    LIBONTOLOGY_PARITY_KG=/path/to/onto.ttl uv run python -m unittest tests.test_ontology_parity

Classes
-------
TestOntologyParity
    Test cases comparing the two inferences on the same graph.
TestOntologyUpdateParity
    Test cases replaying the update loop of the builder with both inferences.

Test Cases
----------
test_nothing_missing
    Tests that everything owlrl infers is also inferred.
test_nothing_unexpected
    Tests that nothing is inferred that owlrl would not infer.
test_update_steps
    Tests that every update step gives the same graph.
"""

import os
import unittest
from collections import Counter
from pathlib import Path
import owlrl
import pyoxigraph as ox
import rdflib
from libontology.ontology_reasoning import OntologyReasoner

OWL = "http://www.w3.org/2002/07/owl#"
XSD = "http://www.w3.org/2001/XMLSchema#"
RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"

# owlrl triples that we decided not to keep (on top of sameAs and literal subjects)
ACCEPTED_MISSING_OBJECTS = {
    OWL + "Thing",
    OWL + "AnnotationProperty",
    "http://www.w3.org/2000/01/rdf-schema#Resource",
    "http://www.w3.org/2000/01/rdf-schema#Datatype",
}


def is_accepted_missing(triple):
    """
    Tell if a triple inferred only by owlrl is one of the accepted differences.

    Parameters
    ----------
    triple : tuple
        A (subject, predicate, object) triple of strings.

    Returns
    -------
    accepted : bool
        True if the triple is axiomatic schema noise of owlrl.
    """
    s, p, o = triple
    return (
        s == o                                     # reflexive subClassOf, equivalentProperty...
        or o in ACCEPTED_MISSING_OBJECTS           # "p rdfs:domain owl:Thing", "xsd:x a rdfs:Datatype"
        or s == OWL + "Nothing"                    # "owl:Nothing rdfs:subClassOf C"
        or (p == OWL + "disjointWith" and s.startswith(XSD))  # disjointness of datatypes
    )


def is_accepted_extra(triple):
    """
    Tell if a triple inferred only by reasonable is one of the accepted differences.

    Parameters
    ----------
    triple : tuple
        A (subject, predicate, object) triple of strings.

    Returns
    -------
    accepted : bool
        True if the triple is "x rdf:type owl:Thing".
    """
    s, p, o = triple
    return p == RDF_TYPE and o == OWL + "Thing"


def triples_of_graph(graph):
    """
    Return the triples of an rdflib graph as comparable strings.

    Blank nodes are skipped because their labels differ between the two
    libraries. owl:sameAs and literals as subject are skipped (accepted loss).

    Parameters
    ----------
    graph : rdflib.Graph
        The graph computed by the old inference.

    Returns
    -------
    triples : set
        Set of (subject, predicate, object) strings.
    """
    def key(term):
        if isinstance(term, rdflib.Literal):
            suffix = f"@{term.language}" if term.language else f"^^{term.datatype or XSD + 'string'}"
            return f'"{term}"{suffix}'
        return str(term)

    return {
        (str(s), str(p), key(o))
        for s, p, o in graph
        if not isinstance(s, (rdflib.BNode, rdflib.Literal))
        and not isinstance(o, rdflib.BNode)
        and str(p) != OWL + "sameAs"
    }


def triples_of_store(store):
    """
    Return the triples of a pyoxigraph store as comparable strings.

    Parameters
    ----------
    store : pyoxigraph.Store
        The store computed by the new inference.

    Returns
    -------
    triples : set
        Set of (subject, predicate, object) strings, same format as triples_of_graph.
    """
    def key(term):
        if isinstance(term, ox.Literal):
            suffix = f"@{term.language}" if term.language else f"^^{term.datatype.value}"
            return f'"{term.value}"{suffix}'
        return term.value

    return {
        (q.subject.value, q.predicate.value, key(q.object))
        for q in store
        if not isinstance(q.subject, ox.BlankNode)
        and not isinstance(q.object, ox.BlankNode)
        and q.predicate.value != OWL + "sameAs"
    }


def report(title, triples, limit=15):
    """
    Build a readable message: number of triples per predicate, then some examples.

    Parameters
    ----------
    title : str
        The title of the message.
    triples : set
        The triples to describe.
    limit : int
        The number of examples to show.

    Returns
    -------
    message : str
        The message shown when a test fails.
    """
    lines = [f"{title}: {len(triples)}"]
    for predicate, count in Counter(p for _, p, _ in triples).most_common():
        lines.append(f"  {count:6d}  {predicate}")
    lines += ["  e.g. " + " ".join(t) for t in sorted(triples)[:limit]]
    return "\n".join(lines)


def load_store(path):
    """Load a turtle or N-Triples file into a new pyoxigraph store."""
    store = ox.Store()
    store.load(path=path, format=ox.RdfFormat.from_extension(Path(path).suffix[1:]))
    return store


class TestOntologyParity(unittest.TestCase):
    """
    A class to compare the new inference with owlrl on the same graph.

    Methods
    -------
    setUpClass()
        Computes both closures once.
    test_nothing_missing()
        Tests that everything owlrl infers is also inferred.
    test_nothing_unexpected()
        Tests that nothing is inferred that owlrl would not infer.
    """

    @classmethod
    def setUpClass(cls):
        """
        Compute the old closure (owlrl) and the new closure (reasonable + patch rules).
        """
        cls.ontology_path = os.environ.get("LIBONTOLOGY_PARITY_KG", "./tests/test_parity/test_kg.nt")

        graph = rdflib.Graph()
        graph.parse(cls.ontology_path)
        owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(graph)
        cls.old = triples_of_graph(graph)

        store = load_store(cls.ontology_path)
        OntologyReasoner().materialize(store)
        cls.new = triples_of_store(store)

    def test_nothing_missing(self):
        """Test that everything owlrl infers is also inferred, except the accepted differences."""
        missing = {t for t in self.old - self.new if not is_accepted_missing(t)}
        self.assertEqual(missing, set(), report("MISSING in the new inference", missing))

    def test_nothing_unexpected(self):
        """Test that nothing is inferred that owlrl would not infer, except the accepted differences."""
        extra = {t for t in self.new - self.old if not is_accepted_extra(t)}
        self.assertEqual(extra, set(), report("EXTRA in the new inference", extra))


class TestOntologyUpdateParity(unittest.TestCase):
    """
    A class to replay the update loop of the builder with both inferences.

    The builder runs one libontology-update per query file, and each update
    infers first, then runs the query (see ontology_update.py).

    Methods
    -------
    setUp()
        Initializes the paths of the graph and of the update queries.
    test_update_steps()
        Tests that every update step gives the same graph.
    """

    def setUp(self):
        """
        Set up the paths of the test graph and of the update queries.
        """
        self.ontology_path = os.environ.get("LIBONTOLOGY_PARITY_KG", "./tests/test_parity/test_kg.nt")
        self.query_files = sorted(Path("./tests/test_parity").glob("*.sparql"))

    def test_update_steps(self):
        """Test that every update step gives the same graph with both inferences."""
        graph = rdflib.Graph()
        graph.parse(self.ontology_path)
        store = load_store(self.ontology_path)
        reasoner = OntologyReasoner()

        for query_file in self.query_files:
            query = query_file.read_text(encoding="utf-8")
            owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(graph)
            graph.update(query)
            reasoner.materialize(store)
            store.update(query)

            with self.subTest(query=query_file.name):
                old, new = triples_of_graph(graph), triples_of_store(store)
                missing = {t for t in old - new if not is_accepted_missing(t)}
                extra = {t for t in new - old if not is_accepted_extra(t)}
                self.assertEqual(missing, set(), report("MISSING after this step", missing))
                self.assertEqual(extra, set(), report("EXTRA after this step", extra))


if __name__ == "__main__":
    unittest.main()
