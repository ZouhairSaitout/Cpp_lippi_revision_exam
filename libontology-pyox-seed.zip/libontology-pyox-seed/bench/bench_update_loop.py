#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Copyright (c) 2023-2026 Orange. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#     1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#     2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#     3. All advertising materials mentioning features or use of this software must display the following acknowledgement:
#     This product includes software developed by Orange.
#     4. Neither the name of Orange nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY Orange "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Orange BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

"""
Module for comparing the speed of the old and the new update loop.

It replays the update loop of the builder (builder_functions.sh: one
libontology-update per query file). Each step reads a turtle file, infers,
runs the update query and writes a turtle file, like the command does.

Functions
---------
old_step(source, query, destination, times)
    One update step with rdflib + owlrl.
new_step(source, query, destination, times)
    One update step with pyoxigraph + reasonable + patch rules.
run_loop(name, step, ontology, queries) -> float
    Runs every update step and prints the times.
main()
    Command-line interface for the benchmark.
"""

import argparse
import os
import sys
import tempfile
import time
from pathlib import Path
import owlrl
import pyoxigraph as ox
import rdflib
from libontology.ontology_reasoning import OntologyReasoner


def old_step(source, query, destination, times):
    """
    Run one update step with rdflib + owlrl (what ontology_update.py does today).

    Parameters
    ----------
    source : str
        The ontology file to update.
    query : str
        The SPARQL UPDATE query.
    destination : str
        The updated ontology file.
    times : dict
        The times of each phase, updated in place.
    """
    start = time.perf_counter()
    graph = rdflib.Graph()
    graph.parse(source)
    times["load"] += time.perf_counter() - start

    start = time.perf_counter()
    owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(graph)
    times["infer"] += time.perf_counter() - start

    start = time.perf_counter()
    graph.update(query)
    times["update"] += time.perf_counter() - start

    start = time.perf_counter()
    graph.serialize(destination=destination, format="turtle")
    times["save"] += time.perf_counter() - start


def new_step(source, query, destination, times):
    """
    Run one update step with pyoxigraph + reasonable + patch rules.

    Parameters
    ----------
    source : str
        The ontology file to update.
    query : str
        The SPARQL UPDATE query.
    destination : str
        The updated ontology file.
    times : dict
        The times of each phase, updated in place.
    """
    start = time.perf_counter()
    store = ox.Store()
    store.load(path=source, format=ox.RdfFormat.from_extension(Path(source).suffix[1:]))
    times["load"] += time.perf_counter() - start

    start = time.perf_counter()
    OntologyReasoner().materialize(store)
    times["infer"] += time.perf_counter() - start

    start = time.perf_counter()
    store.update(query)
    times["update"] += time.perf_counter() - start

    start = time.perf_counter()
    store.dump(destination, format=ox.RdfFormat.TURTLE, from_graph=ox.DefaultGraph())
    times["save"] += time.perf_counter() - start


def run_loop(name, step, ontology, queries):
    """
    Run every update step, one after the other, and print the times.

    Parameters
    ----------
    name : str
        The name shown in the output ("old" or "new").
    step : function
        old_step or new_step.
    ontology : str
        The ontology file to start from.
    queries : list
        The SPARQL UPDATE queries, in order.

    Returns
    -------
    total : float
        The total time in seconds.
    """
    times = {"load": 0.0, "infer": 0.0, "update": 0.0, "save": 0.0}
    with tempfile.TemporaryDirectory() as temp_dir:
        current = ontology
        for i, query in enumerate(queries):
            destination = os.path.join(temp_dir, f"{name}_{i}.ttl")
            step(current, query, destination, times)
            current = destination
    total = sum(times.values())
    details = "  ".join(f"{phase} {seconds:7.2f}s" for phase, seconds in times.items())
    sys.stdout.write(f"{name:4s} total {total:7.2f}s  {details}\n")
    return total


def main():
    """Parse command line arguments and compare the old and the new update loop."""
    parser = argparse.ArgumentParser(
        description="Compare the speed of the update loop with owlrl and with reasonable."
    )
    parser.add_argument("--ontology", help="ontology file", required=True)
    parser.add_argument(
        "--queries-dir", help="directory with the SPARQL update files", required=True
    )
    args = parser.parse_args()

    query_files = sorted(Path(args.queries_dir).glob("*.sparql"))
    if not query_files:
        sys.stderr.write(f"\033[91m[-] No query files found in {args.queries_dir}\033[0m\n")
        sys.exit(1)
    queries = [p.read_text(encoding="utf-8") for p in query_files]

    sys.stderr.write(f"\033[96m[*] {len(queries)} update steps on {args.ontology}\033[0m\n")
    old_total = run_loop("old", old_step, args.ontology, queries)
    new_total = run_loop("new", new_step, args.ontology, queries)
    sys.stderr.write(f"\033[92m[+] Speed-up: x{old_total / new_total:.1f}\033[0m\n")


if __name__ == "__main__":
    main()
